# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr13-dashboard.spec.ts >> FR-13 / FR-12 Admin access >> A04 - A non-admin JWT placed in the admin web must not open the dashboard (FR-12, SEC-03)
- Location: tests\fr13-dashboard.spec.ts:202:5

# Error details

```
Error: the login form must be shown

expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Admin Login' })
Expected: visible
Timeout: 7000ms
Error: element(s) not found

Call log:
  - the login form must be shown getByRole('heading', { name: 'Admin Login' }) with timeout 7000ms
  - waiting for getByRole('heading', { name: 'Admin Login' })

```

```yaml
- heading "EShop Admin" [level=1]
- list:
  - listitem: Dashboard
  - listitem: Danh mục
  - listitem: Sản phẩm
  - listitem: Mã Giảm Giá
  - listitem: Đơn hàng
  - listitem: Người dùng
  - listitem: Đăng xuất
- heading "Dashboard" [level=2]
- heading "Tổng doanh thu (Delivered)" [level=3]
- paragraph: 12,891,201,888 ₫
- heading "Tổng số đơn hàng" [level=3]
- paragraph: "96"
```

# Test source

```ts
  97  | test.beforeAll(async ({ request }) => {
  98  |   await ensureAtLeastOneOrder(request);
  99  | });
  100 | 
  101 | test.describe('FR-13 Dashboard figures', () => {
  102 |   for (const sc of scenarios) {
  103 |     test(`${sc.id} - ${sc.title}`, async ({ page, request }) => {
  104 |       const adminToken = await loginApi(request, 'admin');
  105 |       const userToken = await loginApi(request, 'user');
  106 |       const before = await listOrders(request, adminToken);
  107 | 
  108 |       // ---------------------------------------------------------------- absolute value
  109 |       if (sc.mode === 'absolute') {
  110 |         await openAdmin(page, { token: adminToken });
  111 |         await waitDashboardLoaded(page);
  112 |         await expect
  113 |           .poll(() => readKpi(revenueTile(page)), {
  114 |             message: 'Dashboard revenue must equal the sum of total_amount of ALL delivered orders (SRS FR-13)',
  115 |           })
  116 |           .toBe(revenueOf(before));
  117 |         await expect
  118 |           .poll(() => readKpi(orderCountTile(page)), {
  119 |             message: 'Dashboard total orders must equal the number of orders in the system (SRS FR-13)',
  120 |           })
  121 |           .toBe(before.length);
  122 |         return;
  123 |       }
  124 | 
  125 |       // ---------------------------------------------------------------- orders are arranged through the API
  126 |       if (sc.mode === 'api-seed') {
  127 |         await openAdmin(page, { token: adminToken });
  128 |         await waitDashboardLoaded(page);
  129 |         const revenue0 = await readKpi(revenueTile(page));
  130 |         const count0 = await readKpi(orderCountTile(page));
  131 | 
  132 |         for (const o of sc.orders) {
  133 |           const id = await createOrder(request, userToken, o.amount);
  134 |           await moveOrderTo(request, adminToken, id, o.finalStatus);
  135 |         }
  136 | 
  137 |         // The data row must agree with the SRS rule, otherwise the data file (not the SUT) is wrong.
  138 |         const after = await listOrders(request, adminToken);
  139 |         expect(revenueOf(after) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  140 |         expect(after.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  141 | 
  142 |         await page.reload();
  143 |         await waitDashboardLoaded(page);
  144 |         await expectRevenueDelta(page, revenue0, sc.expect.revenueDelta as number);
  145 |         await expectCountDelta(page, count0, sc.expect.countDelta as number, sc.countVerdict);
  146 |         return;
  147 |       }
  148 | 
  149 |       // ---------------------------------------------------------------- the status is changed with the admin UI buttons
  150 |       if (sc.mode === 'ui-walk') {
  151 |         const amount = sc.orders[0].amount;
  152 |         const id = await createOrder(request, userToken, amount); // stays 'pending'
  153 | 
  154 |         await openAdmin(page, { token: adminToken });
  155 |         await waitDashboardLoaded(page);
  156 |         const revenue0 = await readKpi(revenueTile(page));
  157 |         const count0 = await readKpi(orderCountTile(page)); // already includes the new pending order
  158 | 
  159 |         await goToTab(page, 'Đơn hàng');
  160 |         const row = orderRow(page, id);
  161 |         await expect(row.locator('span').filter({ hasText: STATUS_LABEL.pending })).toBeVisible();
  162 | 
  163 |         for (const next of sc.walk ?? []) {
  164 |           await row.getByRole('button', { name: ACTION_BUTTON[next], exact: true }).click();
  165 |           await expect(row.locator('span').filter({ hasText: STATUS_LABEL[next] })).toBeVisible();
  166 | 
  167 |           // After every click the dashboard must follow the SRS rule: revenue moves only when 'delivered' is reached.
  168 |           await goToTab(page, 'Dashboard');
  169 |           await expectRevenueDelta(page, revenue0, next === 'delivered' ? amount : 0);
  170 |           await expectCountDelta(page, count0, 0, sc.countVerdict);
  171 |           await goToTab(page, 'Đơn hàng');
  172 |         }
  173 | 
  174 |         const finalList = await listOrders(request, adminToken);
  175 |         expect(revenueOf(finalList) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  176 |         expect(finalList.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  177 |         return;
  178 |       }
  179 | 
  180 |       // ---------------------------------------------------------------- final states offer no action (FR-10)
  181 |       const finalStatus = sc.orders[0].finalStatus;
  182 |       const id = await createOrder(request, userToken, sc.orders[0].amount);
  183 |       await moveOrderTo(request, adminToken, id, finalStatus);
  184 | 
  185 |       await openAdmin(page, { token: adminToken });
  186 |       await goToTab(page, 'Đơn hàng');
  187 |       const row = orderRow(page, id);
  188 |       await expect(row.locator('span').filter({ hasText: STATUS_LABEL[finalStatus] })).toBeVisible();
  189 |       // SRS FR-10: delivered / canceled are final states, no transition may be offered.
  190 |       await expect(row.getByRole('button'), 'a final-state order must offer no action button').toHaveCount(0);
  191 |     });
  192 |   }
  193 | });
  194 | 
  195 | test.describe('FR-13 / FR-12 Admin access', () => {
  196 |   const expectLoginForm = async (page: Page) => {
> 197 |     await expect(loginHeading(page), 'the login form must be shown').toBeVisible();
      |                                                                      ^ Error: the login form must be shown
  198 |     await expect(dashboardHeading(page), 'the dashboard must not be shown').toBeHidden();
  199 |   };
  200 | 
  201 |   for (const ac of accessCases) {
  202 |     test(`${ac.id} - ${ac.title}`, async ({ page, request }) => {
  203 |       const dialogs = captureDialogs(page);
  204 | 
  205 |       if (ac.kind === 'no-token') {
  206 |         await openAdmin(page);
  207 |         await expectLoginForm(page);
  208 |       }
  209 | 
  210 |       if (ac.kind === 'inject-token') {
  211 |         const token = ac.token === 'user' ? await loginApi(request, 'user') : (ac.tokenValue as string);
  212 |         await openAdmin(page, { token, waitForOrders: false });
  213 |         await expectLoginForm(page);
  214 |       }
  215 | 
  216 |       if (ac.kind === 'ui-login') {
  217 |         const creds =
  218 |           ac.account === 'throwaway-wrong-password'
  219 |             ? { email: (await registerThrowawayUser(request)).email, password: 'WrongPass1!' }
  220 |             : ACCOUNTS[ac.account as 'admin' | 'user'];
  221 | 
  222 |         await openAdmin(page);
  223 |         await uiLogin(page, creds.email, creds.password);
  224 | 
  225 |         if (ac.expect === 'dashboard') {
  226 |           await expect(dashboardHeading(page)).toBeVisible();
  227 |           await expect(revenueTile(page)).toBeVisible();
  228 |           await expect(orderCountTile(page)).toBeVisible();
  229 |           expect(await page.evaluate(() => window.localStorage.getItem('adminToken'))).toBeTruthy();
  230 |         } else {
  231 |           await expectLoginForm(page);
  232 |           expect(await page.evaluate(() => window.localStorage.getItem('adminToken'))).toBeNull();
  233 |           // The SRS does not define the message text, so it is recorded, not asserted.
  234 |           test.info().annotations.push({
  235 |             type: 'CLARIFY',
  236 |             description: `Message shown to the user: ${dialogs.join(' | ') || '(none)'}`,
  237 |           });
  238 |         }
  239 |       }
  240 |     });
  241 |   }
  242 | });
  243 | 
```