# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr13-dashboard.spec.ts >> FR-13 Dashboard figures >> S13 - Revenue tile equals the sum of all delivered orders in the system, order tile equals the number of orders
- Location: tests\fr13-dashboard.spec.ts:103:5

# Error details

```
Error: Dashboard revenue must equal the sum of total_amount of ALL delivered orders (SRS FR-13)

Dashboard revenue must equal the sum of total_amount of ALL delivered orders (SRS FR-13)

expect(received).toBe(expected) // Object.is equality

Expected: 6445600944
Received: 12891201888

Call Log:
- Timeout 7000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - heading "EShop Admin" [level=1] [ref=e5]
    - list [ref=e6]:
      - listitem [ref=e7] [cursor=pointer]: Dashboard
      - listitem [ref=e8] [cursor=pointer]: Danh mục
      - listitem [ref=e9] [cursor=pointer]: Sản phẩm
      - listitem [ref=e10] [cursor=pointer]: Mã Giảm Giá
      - listitem [ref=e11] [cursor=pointer]: Đơn hàng
      - listitem [ref=e12] [cursor=pointer]: Người dùng
      - listitem [ref=e13] [cursor=pointer]: Đăng xuất
  - generic [ref=e15]:
    - heading "Dashboard" [level=2] [ref=e16]
    - generic [ref=e17]:
      - generic [ref=e18]:
        - heading "Tổng doanh thu (Delivered)" [level=3] [ref=e19]
        - paragraph [ref=e20]: 12,891,201,888 ₫
      - generic [ref=e21]:
        - heading "Tổng số đơn hàng" [level=3] [ref=e22]
        - paragraph [ref=e23]: "96"
```

# Test source

```ts
  16  |   ACTION_BUTTON,
  17  |   STATUS_LABEL,
  18  |   captureDialogs,
  19  |   dashboardHeading,
  20  |   goToTab,
  21  |   loginHeading,
  22  |   openAdmin,
  23  |   orderCountTile,
  24  |   orderRow,
  25  |   readKpi,
  26  |   revenueTile,
  27  |   uiLogin,
  28  |   waitDashboardLoaded,
  29  | } from './helpers/admin';
  30  | 
  31  | /**
  32  |  * FR-13 Dashboard (admin web, http://localhost:5174)
  33  |  * SRS: revenue = sum of total_amount of orders with status 'delivered'; also show the total number of orders.
  34  |  * Related: FR-12 access control, FR-10 order state machine (the dashboard depends on order status).
  35  |  *
  36  |  * Oracle = the SRS, applied to the order list returned by GET /api/admin/orders (verified in HW02).
  37  |  * Test data = data/fr13-dashboard.json and data/fr13-access.json.
  38  |  *
  39  |  * Why most scenarios check a CHANGE (delta) of the tiles: the database already holds old orders, so the absolute
  40  |  * numbers are arbitrary. A delta isolates the rule under test ("a pending order adds nothing"), and one dedicated
  41  |  * scenario (S13) anchors the absolute value.
  42  |  */
  43  | 
  44  | type Scenario = {
  45  |   id: string;
  46  |   title: string;
  47  |   mode: 'api-seed' | 'ui-walk' | 'final-state' | 'absolute';
  48  |   orders: { amount: number; finalStatus: Status }[];
  49  |   walk?: Status[];
  50  |   expect: { revenueDelta?: number; countDelta?: number; noActionButtons?: boolean };
  51  |   countVerdict?: 'firm' | 'clarify';
  52  |   source?: string;
  53  | };
  54  | 
  55  | type AccessCase = {
  56  |   id: string;
  57  |   title: string;
  58  |   kind: 'ui-login' | 'no-token' | 'inject-token';
  59  |   account?: 'admin' | 'user' | 'throwaway-wrong-password';
  60  |   token?: 'user' | 'literal';
  61  |   tokenValue?: string;
  62  |   expect: 'reject' | 'dashboard' | 'login-form';
  63  |   source?: string;
  64  | };
  65  | 
  66  | const scenarios = loadData<Scenario[]>('fr13-dashboard.json');
  67  | const accessCases = loadData<AccessCase[]>('fr13-access.json');
  68  | 
  69  | const CLARIFY_COUNT =
  70  |   'SRS does not say whether canceled orders are part of "total number of orders"; the value shown is recorded, not judged.';
  71  | 
  72  | /** Revenue tile must have moved by `delta` since `base` (assertion pattern: polling numeric equality). */
  73  | async function expectRevenueDelta(page: Page, base: number, delta: number) {
  74  |   await expect
  75  |     .poll(async () => (await readKpi(revenueTile(page))) - base, {
  76  |       message: `Dashboard revenue must change by ${delta} (SRS FR-13: only delivered orders are summed)`,
  77  |     })
  78  |     .toBe(delta);
  79  | }
  80  | 
  81  | async function expectCountDelta(page: Page, base: number, delta: number, verdict: 'firm' | 'clarify' = 'firm') {
  82  |   if (verdict === 'clarify') {
  83  |     const shown = await readKpi(orderCountTile(page));
  84  |     test.info().annotations.push({
  85  |       type: 'CLARIFY',
  86  |       description: `${CLARIFY_COUNT} Order tile moved from ${base} to ${shown} (expected change if all orders count: ${delta}).`,
  87  |     });
  88  |     return;
  89  |   }
  90  |   await expect
  91  |     .poll(async () => (await readKpi(orderCountTile(page))) - base, {
  92  |       message: `Dashboard total orders must change by ${delta} (SRS FR-13)`,
  93  |     })
  94  |     .toBe(delta);
  95  | }
  96  | 
  97  | test.beforeAll(async ({ request }) => {
  98  |   await ensureAtLeastOneOrder(request);
  99  | });
  100 | 
  101 | test.describe('FR-13 Dashboard figures', () => {
  102 |   for (const sc of scenarios) {
  103 |     test(`${sc.id} - ${sc.title}`, async ({ page, request }) => {
  104 |       const adminToken = await loginApi(request, 'admin');
  105 |       const userToken = await loginApi(request, 'user');
  106 |       const before = await listOrders(request, adminToken);
  107 | 
  108 |       // ---------------------------------------------------------------- absolute value
  109 |       if (sc.mode === 'absolute') {
  110 |         await openAdmin(page, { token: adminToken });
  111 |         await waitDashboardLoaded(page);
  112 |         await expect
  113 |           .poll(() => readKpi(revenueTile(page)), {
  114 |             message: 'Dashboard revenue must equal the sum of total_amount of ALL delivered orders (SRS FR-13)',
  115 |           })
> 116 |           .toBe(revenueOf(before));
      |            ^ Error: Dashboard revenue must equal the sum of total_amount of ALL delivered orders (SRS FR-13)
  117 |         await expect
  118 |           .poll(() => readKpi(orderCountTile(page)), {
  119 |             message: 'Dashboard total orders must equal the number of orders in the system (SRS FR-13)',
  120 |           })
  121 |           .toBe(before.length);
  122 |         return;
  123 |       }
  124 | 
  125 |       // ---------------------------------------------------------------- orders are arranged through the API
  126 |       if (sc.mode === 'api-seed') {
  127 |         await openAdmin(page, { token: adminToken });
  128 |         await waitDashboardLoaded(page);
  129 |         const revenue0 = await readKpi(revenueTile(page));
  130 |         const count0 = await readKpi(orderCountTile(page));
  131 | 
  132 |         for (const o of sc.orders) {
  133 |           const id = await createOrder(request, userToken, o.amount);
  134 |           await moveOrderTo(request, adminToken, id, o.finalStatus);
  135 |         }
  136 | 
  137 |         // The data row must agree with the SRS rule, otherwise the data file (not the SUT) is wrong.
  138 |         const after = await listOrders(request, adminToken);
  139 |         expect(revenueOf(after) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  140 |         expect(after.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  141 | 
  142 |         await page.reload();
  143 |         await waitDashboardLoaded(page);
  144 |         await expectRevenueDelta(page, revenue0, sc.expect.revenueDelta as number);
  145 |         await expectCountDelta(page, count0, sc.expect.countDelta as number, sc.countVerdict);
  146 |         return;
  147 |       }
  148 | 
  149 |       // ---------------------------------------------------------------- the status is changed with the admin UI buttons
  150 |       if (sc.mode === 'ui-walk') {
  151 |         const amount = sc.orders[0].amount;
  152 |         const id = await createOrder(request, userToken, amount); // stays 'pending'
  153 | 
  154 |         await openAdmin(page, { token: adminToken });
  155 |         await waitDashboardLoaded(page);
  156 |         const revenue0 = await readKpi(revenueTile(page));
  157 |         const count0 = await readKpi(orderCountTile(page)); // already includes the new pending order
  158 | 
  159 |         await goToTab(page, 'Đơn hàng');
  160 |         const row = orderRow(page, id);
  161 |         await expect(row.locator('span').filter({ hasText: STATUS_LABEL.pending })).toBeVisible();
  162 | 
  163 |         for (const next of sc.walk ?? []) {
  164 |           await row.getByRole('button', { name: ACTION_BUTTON[next], exact: true }).click();
  165 |           await expect(row.locator('span').filter({ hasText: STATUS_LABEL[next] })).toBeVisible();
  166 | 
  167 |           // After every click the dashboard must follow the SRS rule: revenue moves only when 'delivered' is reached.
  168 |           await goToTab(page, 'Dashboard');
  169 |           await expectRevenueDelta(page, revenue0, next === 'delivered' ? amount : 0);
  170 |           await expectCountDelta(page, count0, 0, sc.countVerdict);
  171 |           await goToTab(page, 'Đơn hàng');
  172 |         }
  173 | 
  174 |         const finalList = await listOrders(request, adminToken);
  175 |         expect(revenueOf(finalList) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  176 |         expect(finalList.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  177 |         return;
  178 |       }
  179 | 
  180 |       // ---------------------------------------------------------------- final states offer no action (FR-10)
  181 |       const finalStatus = sc.orders[0].finalStatus;
  182 |       const id = await createOrder(request, userToken, sc.orders[0].amount);
  183 |       await moveOrderTo(request, adminToken, id, finalStatus);
  184 | 
  185 |       await openAdmin(page, { token: adminToken });
  186 |       await goToTab(page, 'Đơn hàng');
  187 |       const row = orderRow(page, id);
  188 |       await expect(row.locator('span').filter({ hasText: STATUS_LABEL[finalStatus] })).toBeVisible();
  189 |       // SRS FR-10: delivered / canceled are final states, no transition may be offered.
  190 |       await expect(row.getByRole('button'), 'a final-state order must offer no action button').toHaveCount(0);
  191 |     });
  192 |   }
  193 | });
  194 | 
  195 | test.describe('FR-13 / FR-12 Admin access', () => {
  196 |   const expectLoginForm = async (page: Page) => {
  197 |     await expect(loginHeading(page), 'the login form must be shown').toBeVisible();
  198 |     await expect(dashboardHeading(page), 'the dashboard must not be shown').toBeHidden();
  199 |   };
  200 | 
  201 |   for (const ac of accessCases) {
  202 |     test(`${ac.id} - ${ac.title}`, async ({ page, request }) => {
  203 |       const dialogs = captureDialogs(page);
  204 | 
  205 |       if (ac.kind === 'no-token') {
  206 |         await openAdmin(page);
  207 |         await expectLoginForm(page);
  208 |       }
  209 | 
  210 |       if (ac.kind === 'inject-token') {
  211 |         const token = ac.token === 'user' ? await loginApi(request, 'user') : (ac.tokenValue as string);
  212 |         await openAdmin(page, { token, waitForOrders: false });
  213 |         await expectLoginForm(page);
  214 |       }
  215 | 
  216 |       if (ac.kind === 'ui-login') {
```