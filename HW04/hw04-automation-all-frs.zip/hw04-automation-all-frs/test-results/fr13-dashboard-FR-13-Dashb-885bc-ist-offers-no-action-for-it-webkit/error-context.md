# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr13-dashboard.spec.ts >> FR-13 Dashboard figures >> S12 - FR-10: a canceled order is a final state, the order list offers no action for it
- Location: tests\fr13-dashboard.spec.ts:103:5

# Error details

```
Error: a final-state order must offer no action button

expect(locator).toHaveCount(expected) failed

Locator:  locator('tr').filter({ has: getByRole('cell', { name: '#96', exact: true }) }).getByRole('button')
Expected: 0
Received: 1
Timeout:  7000ms

Call log:
  - a final-state order must offer no action button locator('tr').filter({ has: getByRole('cell', { name: '#96', exact: true }) }).getByRole('button') with timeout 7000ms
  - waiting for locator('tr').filter({ has: getByRole('cell', { name: '#96', exact: true }) }).getByRole('button')
    17 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - heading "EShop Admin" [level=1] [ref=e5]
    - list [ref=e6]:
      - listitem [ref=e7] [cursor=pointer]: Dashboard
      - listitem [ref=e8] [cursor=pointer]: Danh mục
      - listitem [ref=e9] [cursor=pointer]: Sản phẩm
      - listitem [ref=e10] [cursor=pointer]: Mã Giảm Giá
      - listitem [ref=e11] [cursor=pointer]: Đơn hàng
      - listitem [ref=e12] [cursor=pointer]: Người dùng
      - listitem [ref=e13] [cursor=pointer]: Đăng xuất
  - generic [ref=e15]:
    - heading "Quản lý Đơn hàng" [level=2] [ref=e16]
    - table [ref=e17]:
      - rowgroup [ref=e18]:
        - row [ref=e19]:
          - columnheader "ID" [ref=e20]
          - columnheader "Người đặt" [ref=e21]
          - columnheader "Tổng tiền" [ref=e22]
          - columnheader "Địa chỉ" [ref=e23]
          - columnheader "Trạng thái" [ref=e24]
          - columnheader "Hành động" [ref=e25]
      - rowgroup [ref=e26]:
        - row [ref=e27]:
          - cell "#96" [ref=e28]
          - cell "Test User" [ref=e29]
          - cell "120,000 ₫" [ref=e30]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e31]
          - cell "Đã hủy" [ref=e32]
          - cell [ref=e33]:
            - button "Đánh dấu Đã giao" [ref=e35] [cursor=pointer]
        - row [ref=e36]:
          - cell "#95" [ref=e37]
          - cell "Test User" [ref=e38]
          - cell "120,000 ₫" [ref=e39]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e40]
          - cell "Đã giao" [ref=e41]
          - cell [ref=e42]
        - row [ref=e43]:
          - cell "#94" [ref=e44]
          - cell "Test User" [ref=e45]
          - cell "180,000 ₫" [ref=e46]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e47]
          - cell "Đã hủy" [ref=e48]
          - cell [ref=e49]:
            - button "Đánh dấu Đã giao" [ref=e51] [cursor=pointer]
        - row [ref=e52]:
          - cell "#93" [ref=e53]
          - cell "Test User" [ref=e54]
          - cell "180,000 ₫" [ref=e55]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e56]
          - cell "Đã giao" [ref=e57]
          - cell [ref=e58]
        - row [ref=e59]:
          - cell "#92" [ref=e60]
          - cell "Test User" [ref=e61]
          - cell "99,000 ₫" [ref=e62]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e63]
          - cell "Chờ xác nhận" [ref=e64]
          - cell [ref=e65]:
            - generic [ref=e66]:
              - button "Xác nhận" [ref=e67] [cursor=pointer]
              - button "Hủy" [ref=e68] [cursor=pointer]
        - row [ref=e69]:
          - cell "#91" [ref=e70]
          - cell "Test User" [ref=e71]
          - cell "350,000 ₫" [ref=e72]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e73]
          - cell "Đã giao" [ref=e74]
          - cell [ref=e75]
        - row [ref=e76]:
          - cell "#90" [ref=e77]
          - cell "Test User" [ref=e78]
          - cell "200,000 ₫" [ref=e79]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e80]
          - cell "Đã giao" [ref=e81]
          - cell [ref=e82]
        - row [ref=e83]:
          - cell "#89" [ref=e84]
          - cell "Test User" [ref=e85]
          - cell "2,147,483,647 ₫" [ref=e86]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e87]
          - cell "Đã giao" [ref=e88]
          - cell [ref=e89]
        - row [ref=e90]:
          - cell "#88" [ref=e91]
          - cell "Test User" [ref=e92]
          - cell "1 ₫" [ref=e93]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e94]
          - cell "Đã giao" [ref=e95]
          - cell [ref=e96]
        - row [ref=e97]:
          - cell "#87" [ref=e98]
          - cell "Test User" [ref=e99]
          - cell "150,000 ₫" [ref=e100]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e101]
          - cell "Đã hủy" [ref=e102]
          - cell [ref=e103]:
            - button "Đánh dấu Đã giao" [ref=e105] [cursor=pointer]
        - row [ref=e106]:
          - cell "#86" [ref=e107]
          - cell "Test User" [ref=e108]
          - cell "150,000 ₫" [ref=e109]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e110]
          - cell "Đang giao" [ref=e111]
          - cell [ref=e112]:
            - button "Hoàn thành" [ref=e114] [cursor=pointer]
        - row [ref=e115]:
          - cell "#85" [ref=e116]
          - cell "Test User" [ref=e117]
          - cell "150,000 ₫" [ref=e118]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e119]
          - cell "Đã xác nhận" [ref=e120]
          - cell [ref=e121]:
            - generic [ref=e122]:
              - button "Giao hàng" [ref=e123] [cursor=pointer]
              - button "Hủy" [ref=e124] [cursor=pointer]
        - row [ref=e125]:
          - cell "#84" [ref=e126]
          - cell "Test User" [ref=e127]
          - cell "150,000 ₫" [ref=e128]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e129]
          - cell "Chờ xác nhận" [ref=e130]
          - cell [ref=e131]:
            - generic [ref=e132]:
              - button "Xác nhận" [ref=e133] [cursor=pointer]
              - button "Hủy" [ref=e134] [cursor=pointer]
        - row [ref=e135]:
          - cell "#83" [ref=e136]
          - cell "Test User" [ref=e137]
          - cell "200,000 ₫" [ref=e138]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e139]
          - cell "Đã giao" [ref=e140]
          - cell [ref=e141]
        - row [ref=e142]:
          - cell "#82" [ref=e143]
          - cell "Test User" [ref=e144]
          - cell "120,000 ₫" [ref=e145]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e146]
          - cell "Đã hủy" [ref=e147]
          - cell [ref=e148]:
            - button "Đánh dấu Đã giao" [ref=e150] [cursor=pointer]
        - row [ref=e151]:
          - cell "#81" [ref=e152]
          - cell "Test User" [ref=e153]
          - cell "120,000 ₫" [ref=e154]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e155]
          - cell "Đã giao" [ref=e156]
          - cell [ref=e157]
        - row [ref=e158]:
          - cell "#80" [ref=e159]
          - cell "Test User" [ref=e160]
          - cell "180,000 ₫" [ref=e161]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e162]
          - cell "Đã hủy" [ref=e163]
          - cell [ref=e164]:
            - button "Đánh dấu Đã giao" [ref=e166] [cursor=pointer]
        - row [ref=e167]:
          - cell "#79" [ref=e168]
          - cell "Test User" [ref=e169]
          - cell "180,000 ₫" [ref=e170]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e171]
          - cell "Đã giao" [ref=e172]
          - cell [ref=e173]
        - row [ref=e174]:
          - cell "#78" [ref=e175]
          - cell "Test User" [ref=e176]
          - cell "99,000 ₫" [ref=e177]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e178]
          - cell "Chờ xác nhận" [ref=e179]
          - cell [ref=e180]:
            - generic [ref=e181]:
              - button "Xác nhận" [ref=e182] [cursor=pointer]
              - button "Hủy" [ref=e183] [cursor=pointer]
        - row [ref=e184]:
          - cell "#77" [ref=e185]
          - cell "Test User" [ref=e186]
          - cell "350,000 ₫" [ref=e187]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e188]
          - cell "Đã giao" [ref=e189]
          - cell [ref=e190]
        - row [ref=e191]:
          - cell "#76" [ref=e192]
          - cell "Test User" [ref=e193]
          - cell "200,000 ₫" [ref=e194]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e195]
          - cell "Đã giao" [ref=e196]
          - cell [ref=e197]
        - row [ref=e198]:
          - cell "#75" [ref=e199]
          - cell "Test User" [ref=e200]
          - cell "2,147,483,647 ₫" [ref=e201]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e202]
          - cell "Đã giao" [ref=e203]
          - cell [ref=e204]
        - row [ref=e205]:
          - cell "#74" [ref=e206]
          - cell "Test User" [ref=e207]
          - cell "1 ₫" [ref=e208]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e209]
          - cell "Đã giao" [ref=e210]
          - cell [ref=e211]
        - row [ref=e212]:
          - cell "#73" [ref=e213]
          - cell "Test User" [ref=e214]
          - cell "150,000 ₫" [ref=e215]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e216]
          - cell "Đã hủy" [ref=e217]
          - cell [ref=e218]:
            - button "Đánh dấu Đã giao" [ref=e220] [cursor=pointer]
        - row [ref=e221]:
          - cell "#72" [ref=e222]
          - cell "Test User" [ref=e223]
          - cell "150,000 ₫" [ref=e224]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e225]
          - cell "Đang giao" [ref=e226]
          - cell [ref=e227]:
            - button "Hoàn thành" [ref=e229] [cursor=pointer]
        - row [ref=e230]:
          - cell "#71" [ref=e231]
          - cell "Test User" [ref=e232]
          - cell "150,000 ₫" [ref=e233]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e234]
          - cell "Đã xác nhận" [ref=e235]
          - cell [ref=e236]:
            - generic [ref=e237]:
              - button "Giao hàng" [ref=e238] [cursor=pointer]
              - button "Hủy" [ref=e239] [cursor=pointer]
        - row [ref=e240]:
          - cell "#70" [ref=e241]
          - cell "Test User" [ref=e242]
          - cell "150,000 ₫" [ref=e243]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e244]
          - cell "Chờ xác nhận" [ref=e245]
          - cell [ref=e246]:
            - generic [ref=e247]:
              - button "Xác nhận" [ref=e248] [cursor=pointer]
              - button "Hủy" [ref=e249] [cursor=pointer]
        - row [ref=e250]:
          - cell "#69" [ref=e251]
          - cell "Test User" [ref=e252]
          - cell "200,000 ₫" [ref=e253]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e254]
          - cell "Đã giao" [ref=e255]
          - cell [ref=e256]
        - row [ref=e257]:
          - cell "#68" [ref=e258]
          - cell "Test User" [ref=e259]
          - cell "120,000 ₫" [ref=e260]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e261]
          - cell "Đã hủy" [ref=e262]
          - cell [ref=e263]:
            - button "Đánh dấu Đã giao" [ref=e265] [cursor=pointer]
        - row [ref=e266]:
          - cell "#67" [ref=e267]
          - cell "Test User" [ref=e268]
          - cell "120,000 ₫" [ref=e269]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e270]
          - cell "Đã giao" [ref=e271]
          - cell [ref=e272]
        - row [ref=e273]:
          - cell "#66" [ref=e274]
          - cell "Test User" [ref=e275]
          - cell "180,000 ₫" [ref=e276]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e277]
          - cell "Đã hủy" [ref=e278]
          - cell [ref=e279]:
            - button "Đánh dấu Đã giao" [ref=e281] [cursor=pointer]
        - row [ref=e282]:
          - cell "#65" [ref=e283]
          - cell "Test User" [ref=e284]
          - cell "180,000 ₫" [ref=e285]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e286]
          - cell "Đã giao" [ref=e287]
          - cell [ref=e288]
        - row [ref=e289]:
          - cell "#64" [ref=e290]
          - cell "Test User" [ref=e291]
          - cell "99,000 ₫" [ref=e292]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e293]
          - cell "Chờ xác nhận" [ref=e294]
          - cell [ref=e295]:
            - generic [ref=e296]:
              - button "Xác nhận" [ref=e297] [cursor=pointer]
              - button "Hủy" [ref=e298] [cursor=pointer]
        - row [ref=e299]:
          - cell "#63" [ref=e300]
          - cell "Test User" [ref=e301]
          - cell "350,000 ₫" [ref=e302]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e303]
          - cell "Đã giao" [ref=e304]
          - cell [ref=e305]
        - row [ref=e306]:
          - cell "#62" [ref=e307]
          - cell "Test User" [ref=e308]
          - cell "200,000 ₫" [ref=e309]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e310]
          - cell "Đã giao" [ref=e311]
          - cell [ref=e312]
        - row [ref=e313]:
          - cell "#61" [ref=e314]
          - cell "Test User" [ref=e315]
          - cell "2,147,483,647 ₫" [ref=e316]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e317]
          - cell "Đã giao" [ref=e318]
          - cell [ref=e319]
        - row [ref=e320]:
          - cell "#60" [ref=e321]
          - cell "Test User" [ref=e322]
          - cell "1 ₫" [ref=e323]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e324]
          - cell "Đã giao" [ref=e325]
          - cell [ref=e326]
        - row [ref=e327]:
          - cell "#59" [ref=e328]
          - cell "Test User" [ref=e329]
          - cell "150,000 ₫" [ref=e330]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e331]
          - cell "Đã hủy" [ref=e332]
          - cell [ref=e333]:
            - button "Đánh dấu Đã giao" [ref=e335] [cursor=pointer]
        - row [ref=e336]:
          - cell "#58" [ref=e337]
          - cell "Test User" [ref=e338]
          - cell "150,000 ₫" [ref=e339]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e340]
          - cell "Đang giao" [ref=e341]
          - cell [ref=e342]:
            - button "Hoàn thành" [ref=e344] [cursor=pointer]
        - row [ref=e345]:
          - cell "#57" [ref=e346]
          - cell "Test User" [ref=e347]
          - cell "150,000 ₫" [ref=e348]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e349]
          - cell "Đã xác nhận" [ref=e350]
          - cell [ref=e351]:
            - generic [ref=e352]:
              - button "Giao hàng" [ref=e353] [cursor=pointer]
              - button "Hủy" [ref=e354] [cursor=pointer]
        - row [ref=e355]:
          - cell "#56" [ref=e356]
          - cell "Test User" [ref=e357]
          - cell "150,000 ₫" [ref=e358]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e359]
          - cell "Chờ xác nhận" [ref=e360]
          - cell [ref=e361]:
            - generic [ref=e362]:
              - button "Xác nhận" [ref=e363] [cursor=pointer]
              - button "Hủy" [ref=e364] [cursor=pointer]
        - row [ref=e365]:
          - cell "#55" [ref=e366]
          - cell "Test User" [ref=e367]
          - cell "200,000 ₫" [ref=e368]
          - cell "123 Le Loi, Q1, TP.HCM" [ref=e369]
          - cell "Đã giao" [ref=e370]
          - cell [ref=e371]
        - row [ref=e372]:
          - cell "#54" [ref=e373]
          - cell "HW04 User" [ref=e374]
          - cell "30,000,000 ₫" [ref=e375]
          - cell "Chưa cập nhật" [ref=e376]
          - cell "Chờ xác nhận" [ref=e377]
          - cell [ref=e378]:
            - generic [ref=e379]:
              - button "Xác nhận" [ref=e380] [cursor=pointer]
              - button "Hủy" [ref=e381] [cursor=pointer]
        - row [ref=e382]:
          - cell "#53" [ref=e383]
          - cell "HW04 User" [ref=e384]
          - cell "0 ₫" [ref=e385]
          - cell "Chưa cập nhật" [ref=e386]
          - cell "Chờ xác nhận" [ref=e387]
          - cell [ref=e388]:
            - generic [ref=e389]:
              - button "Xác nhận" [ref=e390] [cursor=pointer]
              - button "Hủy" [ref=e391] [cursor=pointer]
        - row [ref=e392]:
          - cell "#52" [ref=e393]
          - cell "HW04 User" [ref=e394]
          - cell "58,000,000 ₫" [ref=e395]
          - cell "Chưa cập nhật" [ref=e396]
          - cell "Chờ xác nhận" [ref=e397]
          - cell [ref=e398]:
            - generic [ref=e399]:
              - button "Xác nhận" [ref=e400] [cursor=pointer]
              - button "Hủy" [ref=e401] [cursor=pointer]
        - row [ref=e402]:
          - cell "#51" [ref=e403]
          - cell "HW04 User" [ref=e404]
          - cell "0 ₫" [ref=e405]
          - cell "Chưa cập nhật" [ref=e406]
          - cell "Chờ xác nhận" [ref=e407]
          - cell [ref=e408]:
            - generic [ref=e409]:
              - button "Xác nhận" [ref=e410] [cursor=pointer]
              - button "Hủy" [ref=e411] [cursor=pointer]
        - row [ref=e412]:
          - cell "#50" [ref=e413]
          - cell "HW04 User" [ref=e414]
          - cell "1 ₫" [ref=e415]
          - cell "Chưa cập nhật" [ref=e416]
          - cell "Chờ xác nhận" [ref=e417]
          - cell [ref=e418]:
            - generic [ref=e419]:
              - button "Xác nhận" [ref=e420] [cursor=pointer]
              - button "Hủy" [ref=e421] [cursor=pointer]
        - row [ref=e422]:
          - cell "#49" [ref=e423]
          - cell "HW04 User" [ref=e424]
          - cell "103,000,000 ₫" [ref=e425]
          - cell "Chưa cập nhật" [ref=e426]
          - cell "Chờ xác nhận" [ref=e427]
          - cell [ref=e428]:
            - generic [ref=e429]:
              - button "Xác nhận" [ref=e430] [cursor=pointer]
              - button "Hủy" [ref=e431] [cursor=pointer]
        - row [ref=e432]:
          - cell "#48" [ref=e433]
          - cell "HW04 User" [ref=e434]
          - cell "60,000,000 ₫" [ref=e435]
          - cell "Chưa cập nhật" [ref=e436]
          - cell "Chờ xác nhận" [ref=e437]
          - cell [ref=e438]:
            - generic [ref=e439]:
              - button "Xác nhận" [ref=e440] [cursor=pointer]
              - button "Hủy" [ref=e441] [cursor=pointer]
        - row [ref=e442]:
          - cell "#47" [ref=e443]
          - cell "HW04 User" [ref=e444]
          - cell "58,000,000 ₫" [ref=e445]
          - cell "Chưa cập nhật" [ref=e446]
          - cell "Chờ xác nhận" [ref=e447]
          - cell [ref=e448]:
            - generic [ref=e449]:
              - button "Xác nhận" [ref=e450] [cursor=pointer]
              - button "Hủy" [ref=e451] [cursor=pointer]
        - row [ref=e452]:
          - cell "#46" [ref=e453]
          - cell "HW04 User" [ref=e454]
          - cell "30,000,000 ₫" [ref=e455]
          - cell "Chưa cập nhật" [ref=e456]
          - cell "Chờ xác nhận" [ref=e457]
          - cell [ref=e458]:
            - generic [ref=e459]:
              - button "Xác nhận" [ref=e460] [cursor=pointer]
              - button "Hủy" [ref=e461] [cursor=pointer]
        - row [ref=e462]:
          - cell "#45" [ref=e463]
          - cell "HW04 User" [ref=e464]
          - cell "30,000,000 ₫" [ref=e465]
          - cell "Chưa cập nhật" [ref=e466]
          - cell "Chờ xác nhận" [ref=e467]
          - cell [ref=e468]:
            - generic [ref=e469]:
              - button "Xác nhận" [ref=e470] [cursor=pointer]
              - button "Hủy" [ref=e471] [cursor=pointer]
        - row [ref=e472]:
          - cell "#44" [ref=e473]
          - cell "HW04 User" [ref=e474]
          - cell "0 ₫" [ref=e475]
          - cell "Chưa cập nhật" [ref=e476]
          - cell "Chờ xác nhận" [ref=e477]
          - cell [ref=e478]:
            - generic [ref=e479]:
              - button "Xác nhận" [ref=e480] [cursor=pointer]
              - button "Hủy" [ref=e481] [cursor=pointer]
        - row [ref=e482]:
          - cell "#43" [ref=e483]
          - cell "HW04 User" [ref=e484]
          - cell "58,000,000 ₫" [ref=e485]
          - cell "Chưa cập nhật" [ref=e486]
          - cell "Chờ xác nhận" [ref=e487]
          - cell [ref=e488]:
            - generic [ref=e489]:
              - button "Xác nhận" [ref=e490] [cursor=pointer]
              - button "Hủy" [ref=e491] [cursor=pointer]
        - row [ref=e492]:
          - cell "#42" [ref=e493]
          - cell "HW04 User" [ref=e494]
          - cell "0 ₫" [ref=e495]
          - cell "Chưa cập nhật" [ref=e496]
          - cell "Chờ xác nhận" [ref=e497]
          - cell [ref=e498]:
            - generic [ref=e499]:
              - button "Xác nhận" [ref=e500] [cursor=pointer]
              - button "Hủy" [ref=e501] [cursor=pointer]
        - row [ref=e502]:
          - cell "#41" [ref=e503]
          - cell "HW04 User" [ref=e504]
          - cell "1 ₫" [ref=e505]
          - cell "Chưa cập nhật" [ref=e506]
          - cell "Chờ xác nhận" [ref=e507]
          - cell [ref=e508]:
            - generic [ref=e509]:
              - button "Xác nhận" [ref=e510] [cursor=pointer]
              - button "Hủy" [ref=e511] [cursor=pointer]
        - row [ref=e512]:
          - cell "#40" [ref=e513]
          - cell "HW04 User" [ref=e514]
          - cell "103,000,000 ₫" [ref=e515]
          - cell "Chưa cập nhật" [ref=e516]
          - cell "Chờ xác nhận" [ref=e517]
          - cell [ref=e518]:
            - generic [ref=e519]:
              - button "Xác nhận" [ref=e520] [cursor=pointer]
              - button "Hủy" [ref=e521] [cursor=pointer]
        - row [ref=e522]:
          - cell "#39" [ref=e523]
          - cell "HW04 User" [ref=e524]
          - cell "60,000,000 ₫" [ref=e525]
          - cell "Chưa cập nhật" [ref=e526]
          - cell "Chờ xác nhận" [ref=e527]
          - cell [ref=e528]:
            - generic [ref=e529]:
              - button "Xác nhận" [ref=e530] [cursor=pointer]
              - button "Hủy" [ref=e531] [cursor=pointer]
        - row [ref=e532]:
          - cell "#38" [ref=e533]
          - cell "HW04 User" [ref=e534]
          - cell "58,000,000 ₫" [ref=e535]
          - cell "Chưa cập nhật" [ref=e536]
          - cell "Chờ xác nhận" [ref=e537]
          - cell [ref=e538]:
            - generic [ref=e539]:
              - button "Xác nhận" [ref=e540] [cursor=pointer]
              - button "Hủy" [ref=e541] [cursor=pointer]
        - row [ref=e542]:
          - cell "#37" [ref=e543]
          - cell "HW04 User" [ref=e544]
          - cell "30,000,000 ₫" [ref=e545]
          - cell "Chưa cập nhật" [ref=e546]
          - cell "Chờ xác nhận" [ref=e547]
          - cell [ref=e548]:
            - generic [ref=e549]:
              - button "Xác nhận" [ref=e550] [cursor=pointer]
              - button "Hủy" [ref=e551] [cursor=pointer]
        - row [ref=e552]:
          - cell "#36" [ref=e553]
          - cell "HW04 User" [ref=e554]
          - cell "30,000,000 ₫" [ref=e555]
          - cell "Chưa cập nhật" [ref=e556]
          - cell "Chờ xác nhận" [ref=e557]
          - cell [ref=e558]:
            - generic [ref=e559]:
              - button "Xác nhận" [ref=e560] [cursor=pointer]
              - button "Hủy" [ref=e561] [cursor=pointer]
        - row [ref=e562]:
          - cell "#35" [ref=e563]
          - cell "HW04 User" [ref=e564]
          - cell "0 ₫" [ref=e565]
          - cell "Chưa cập nhật" [ref=e566]
          - cell "Chờ xác nhận" [ref=e567]
          - cell [ref=e568]:
            - generic [ref=e569]:
              - button "Xác nhận" [ref=e570] [cursor=pointer]
              - button "Hủy" [ref=e571] [cursor=pointer]
        - row [ref=e572]:
          - cell "#34" [ref=e573]
          - cell "HW04 User" [ref=e574]
          - cell "58,000,000 ₫" [ref=e575]
          - cell "Chưa cập nhật" [ref=e576]
          - cell "Chờ xác nhận" [ref=e577]
          - cell [ref=e578]:
            - generic [ref=e579]:
              - button "Xác nhận" [ref=e580] [cursor=pointer]
              - button "Hủy" [ref=e581] [cursor=pointer]
        - row [ref=e582]:
          - cell "#33" [ref=e583]
          - cell "HW04 User" [ref=e584]
          - cell "0 ₫" [ref=e585]
          - cell "Chưa cập nhật" [ref=e586]
          - cell "Chờ xác nhận" [ref=e587]
          - cell [ref=e588]:
            - generic [ref=e589]:
              - button "Xác nhận" [ref=e590] [cursor=pointer]
              - button "Hủy" [ref=e591] [cursor=pointer]
        - row [ref=e592]:
          - cell "#32" [ref=e593]
          - cell "HW04 User" [ref=e594]
          - cell "1 ₫" [ref=e595]
          - cell "Chưa cập nhật" [ref=e596]
          - cell "Chờ xác nhận" [ref=e597]
          - cell [ref=e598]:
            - generic [ref=e599]:
              - button "Xác nhận" [ref=e600] [cursor=pointer]
              - button "Hủy" [ref=e601] [cursor=pointer]
        - row [ref=e602]:
          - cell "#31" [ref=e603]
          - cell "HW04 User" [ref=e604]
          - cell "103,000,000 ₫" [ref=e605]
          - cell "Chưa cập nhật" [ref=e606]
          - cell "Chờ xác nhận" [ref=e607]
          - cell [ref=e608]:
            - generic [ref=e609]:
              - button "Xác nhận" [ref=e610] [cursor=pointer]
              - button "Hủy" [ref=e611] [cursor=pointer]
        - row [ref=e612]:
          - cell "#30" [ref=e613]
          - cell "HW04 User" [ref=e614]
          - cell "60,000,000 ₫" [ref=e615]
          - cell "Chưa cập nhật" [ref=e616]
          - cell "Chờ xác nhận" [ref=e617]
          - cell [ref=e618]:
            - generic [ref=e619]:
              - button "Xác nhận" [ref=e620] [cursor=pointer]
              - button "Hủy" [ref=e621] [cursor=pointer]
        - row [ref=e622]:
          - cell "#29" [ref=e623]
          - cell "HW04 User" [ref=e624]
          - cell "58,000,000 ₫" [ref=e625]
          - cell "Chưa cập nhật" [ref=e626]
          - cell "Chờ xác nhận" [ref=e627]
          - cell [ref=e628]:
            - generic [ref=e629]:
              - button "Xác nhận" [ref=e630] [cursor=pointer]
              - button "Hủy" [ref=e631] [cursor=pointer]
        - row [ref=e632]:
          - cell "#28" [ref=e633]
          - cell "HW04 User" [ref=e634]
          - cell "30,000,000 ₫" [ref=e635]
          - cell "Chưa cập nhật" [ref=e636]
          - cell "Chờ xác nhận" [ref=e637]
          - cell [ref=e638]:
            - generic [ref=e639]:
              - button "Xác nhận" [ref=e640] [cursor=pointer]
              - button "Hủy" [ref=e641] [cursor=pointer]
        - row [ref=e642]:
          - cell "#27" [ref=e643]
          - cell "HW04 User" [ref=e644]
          - cell "30,000,000 ₫" [ref=e645]
          - cell "Chưa cập nhật" [ref=e646]
          - cell "Chờ xác nhận" [ref=e647]
          - cell [ref=e648]:
            - generic [ref=e649]:
              - button "Xác nhận" [ref=e650] [cursor=pointer]
              - button "Hủy" [ref=e651] [cursor=pointer]
        - row [ref=e652]:
          - cell "#26" [ref=e653]
          - cell "HW04 User" [ref=e654]
          - cell "0 ₫" [ref=e655]
          - cell "Chưa cập nhật" [ref=e656]
          - cell "Chờ xác nhận" [ref=e657]
          - cell [ref=e658]:
            - generic [ref=e659]:
              - button "Xác nhận" [ref=e660] [cursor=pointer]
              - button "Hủy" [ref=e661] [cursor=pointer]
        - row [ref=e662]:
          - cell "#25" [ref=e663]
          - cell "HW04 User" [ref=e664]
          - cell "58,000,000 ₫" [ref=e665]
          - cell "Chưa cập nhật" [ref=e666]
          - cell "Chờ xác nhận" [ref=e667]
          - cell [ref=e668]:
            - generic [ref=e669]:
              - button "Xác nhận" [ref=e670] [cursor=pointer]
              - button "Hủy" [ref=e671] [cursor=pointer]
        - row [ref=e672]:
          - cell "#24" [ref=e673]
          - cell "HW04 User" [ref=e674]
          - cell "0 ₫" [ref=e675]
          - cell "Chưa cập nhật" [ref=e676]
          - cell "Chờ xác nhận" [ref=e677]
          - cell [ref=e678]:
            - generic [ref=e679]:
              - button "Xác nhận" [ref=e680] [cursor=pointer]
              - button "Hủy" [ref=e681] [cursor=pointer]
        - row [ref=e682]:
          - cell "#23" [ref=e683]
          - cell "HW04 User" [ref=e684]
          - cell "1 ₫" [ref=e685]
          - cell "Chưa cập nhật" [ref=e686]
          - cell "Chờ xác nhận" [ref=e687]
          - cell [ref=e688]:
            - generic [ref=e689]:
              - button "Xác nhận" [ref=e690] [cursor=pointer]
              - button "Hủy" [ref=e691] [cursor=pointer]
        - row [ref=e692]:
          - cell "#22" [ref=e693]
          - cell "HW04 User" [ref=e694]
          - cell "103,000,000 ₫" [ref=e695]
          - cell "Chưa cập nhật" [ref=e696]
          - cell "Chờ xác nhận" [ref=e697]
          - cell [ref=e698]:
            - generic [ref=e699]:
              - button "Xác nhận" [ref=e700] [cursor=pointer]
              - button "Hủy" [ref=e701] [cursor=pointer]
        - row [ref=e702]:
          - cell "#21" [ref=e703]
          - cell "HW04 User" [ref=e704]
          - cell "60,000,000 ₫" [ref=e705]
          - cell "Chưa cập nhật" [ref=e706]
          - cell "Chờ xác nhận" [ref=e707]
          - cell [ref=e708]:
            - generic [ref=e709]:
              - button "Xác nhận" [ref=e710] [cursor=pointer]
              - button "Hủy" [ref=e711] [cursor=pointer]
        - row [ref=e712]:
          - cell "#20" [ref=e713]
          - cell "HW04 User" [ref=e714]
          - cell "58,000,000 ₫" [ref=e715]
          - cell "Chưa cập nhật" [ref=e716]
          - cell "Chờ xác nhận" [ref=e717]
          - cell [ref=e718]:
            - generic [ref=e719]:
              - button "Xác nhận" [ref=e720] [cursor=pointer]
              - button "Hủy" [ref=e721] [cursor=pointer]
        - row [ref=e722]:
          - cell "#19" [ref=e723]
          - cell "HW04 User" [ref=e724]
          - cell "30,000,000 ₫" [ref=e725]
          - cell "Chưa cập nhật" [ref=e726]
          - cell "Chờ xác nhận" [ref=e727]
          - cell [ref=e728]:
            - generic [ref=e729]:
              - button "Xác nhận" [ref=e730] [cursor=pointer]
              - button "Hủy" [ref=e731] [cursor=pointer]
        - row [ref=e732]:
          - cell "#18" [ref=e733]
          - cell "HW04 User" [ref=e734]
          - cell "30,000,000 ₫" [ref=e735]
          - cell "Chưa cập nhật" [ref=e736]
          - cell "Chờ xác nhận" [ref=e737]
          - cell [ref=e738]:
            - generic [ref=e739]:
              - button "Xác nhận" [ref=e740] [cursor=pointer]
              - button "Hủy" [ref=e741] [cursor=pointer]
        - row [ref=e742]:
          - cell "#17" [ref=e743]
          - cell "HW04 User" [ref=e744]
          - cell "0 ₫" [ref=e745]
          - cell "Chưa cập nhật" [ref=e746]
          - cell "Chờ xác nhận" [ref=e747]
          - cell [ref=e748]:
            - generic [ref=e749]:
              - button "Xác nhận" [ref=e750] [cursor=pointer]
              - button "Hủy" [ref=e751] [cursor=pointer]
        - row [ref=e752]:
          - cell "#16" [ref=e753]
          - cell "HW04 User" [ref=e754]
          - cell "58,000,000 ₫" [ref=e755]
          - cell "Chưa cập nhật" [ref=e756]
          - cell "Chờ xác nhận" [ref=e757]
          - cell [ref=e758]:
            - generic [ref=e759]:
              - button "Xác nhận" [ref=e760] [cursor=pointer]
              - button "Hủy" [ref=e761] [cursor=pointer]
        - row [ref=e762]:
          - cell "#15" [ref=e763]
          - cell "HW04 User" [ref=e764]
          - cell "0 ₫" [ref=e765]
          - cell "Chưa cập nhật" [ref=e766]
          - cell "Chờ xác nhận" [ref=e767]
          - cell [ref=e768]:
            - generic [ref=e769]:
              - button "Xác nhận" [ref=e770] [cursor=pointer]
              - button "Hủy" [ref=e771] [cursor=pointer]
        - row [ref=e772]:
          - cell "#14" [ref=e773]
          - cell "HW04 User" [ref=e774]
          - cell "1 ₫" [ref=e775]
          - cell "Chưa cập nhật" [ref=e776]
          - cell "Chờ xác nhận" [ref=e777]
          - cell [ref=e778]:
            - generic [ref=e779]:
              - button "Xác nhận" [ref=e780] [cursor=pointer]
              - button "Hủy" [ref=e781] [cursor=pointer]
        - row [ref=e782]:
          - cell "#13" [ref=e783]
          - cell "HW04 User" [ref=e784]
          - cell "103,000,000 ₫" [ref=e785]
          - cell "Chưa cập nhật" [ref=e786]
          - cell "Chờ xác nhận" [ref=e787]
          - cell [ref=e788]:
            - generic [ref=e789]:
              - button "Xác nhận" [ref=e790] [cursor=pointer]
              - button "Hủy" [ref=e791] [cursor=pointer]
        - row [ref=e792]:
          - cell "#12" [ref=e793]
          - cell "HW04 User" [ref=e794]
          - cell "60,000,000 ₫" [ref=e795]
          - cell "Chưa cập nhật" [ref=e796]
          - cell "Chờ xác nhận" [ref=e797]
          - cell [ref=e798]:
            - generic [ref=e799]:
              - button "Xác nhận" [ref=e800] [cursor=pointer]
              - button "Hủy" [ref=e801] [cursor=pointer]
        - row [ref=e802]:
          - cell "#11" [ref=e803]
          - cell "HW04 User" [ref=e804]
          - cell "58,000,000 ₫" [ref=e805]
          - cell "Chưa cập nhật" [ref=e806]
          - cell "Chờ xác nhận" [ref=e807]
          - cell [ref=e808]:
            - generic [ref=e809]:
              - button "Xác nhận" [ref=e810] [cursor=pointer]
              - button "Hủy" [ref=e811] [cursor=pointer]
        - row [ref=e812]:
          - cell "#10" [ref=e813]
          - cell "HW04 User" [ref=e814]
          - cell "30,000,000 ₫" [ref=e815]
          - cell "Chưa cập nhật" [ref=e816]
          - cell "Chờ xác nhận" [ref=e817]
          - cell [ref=e818]:
            - generic [ref=e819]:
              - button "Xác nhận" [ref=e820] [cursor=pointer]
              - button "Hủy" [ref=e821] [cursor=pointer]
        - row [ref=e822]:
          - cell "#9" [ref=e823]
          - cell "HW04 User" [ref=e824]
          - cell "30,000,000 ₫" [ref=e825]
          - cell "Chưa cập nhật" [ref=e826]
          - cell "Chờ xác nhận" [ref=e827]
          - cell [ref=e828]:
            - generic [ref=e829]:
              - button "Xác nhận" [ref=e830] [cursor=pointer]
              - button "Hủy" [ref=e831] [cursor=pointer]
        - row [ref=e832]:
          - cell "#8" [ref=e833]
          - cell "HW04 User" [ref=e834]
          - cell "0 ₫" [ref=e835]
          - cell "Chưa cập nhật" [ref=e836]
          - cell "Chờ xác nhận" [ref=e837]
          - cell [ref=e838]:
            - generic [ref=e839]:
              - button "Xác nhận" [ref=e840] [cursor=pointer]
              - button "Hủy" [ref=e841] [cursor=pointer]
        - row [ref=e842]:
          - cell "#7" [ref=e843]
          - cell "HW04 User" [ref=e844]
          - cell "58,000,000 ₫" [ref=e845]
          - cell "Chưa cập nhật" [ref=e846]
          - cell "Chờ xác nhận" [ref=e847]
          - cell [ref=e848]:
            - generic [ref=e849]:
              - button "Xác nhận" [ref=e850] [cursor=pointer]
              - button "Hủy" [ref=e851] [cursor=pointer]
        - row [ref=e852]:
          - cell "#6" [ref=e853]
          - cell "HW04 User" [ref=e854]
          - cell "0 ₫" [ref=e855]
          - cell "Chưa cập nhật" [ref=e856]
          - cell "Chờ xác nhận" [ref=e857]
          - cell [ref=e858]:
            - generic [ref=e859]:
              - button "Xác nhận" [ref=e860] [cursor=pointer]
              - button "Hủy" [ref=e861] [cursor=pointer]
        - row [ref=e862]:
          - cell "#5" [ref=e863]
          - cell "HW04 User" [ref=e864]
          - cell "1 ₫" [ref=e865]
          - cell "Chưa cập nhật" [ref=e866]
          - cell "Chờ xác nhận" [ref=e867]
          - cell [ref=e868]:
            - generic [ref=e869]:
              - button "Xác nhận" [ref=e870] [cursor=pointer]
              - button "Hủy" [ref=e871] [cursor=pointer]
        - row [ref=e872]:
          - cell "#4" [ref=e873]
          - cell "HW04 User" [ref=e874]
          - cell "103,000,000 ₫" [ref=e875]
          - cell "Chưa cập nhật" [ref=e876]
          - cell "Chờ xác nhận" [ref=e877]
          - cell [ref=e878]:
            - generic [ref=e879]:
              - button "Xác nhận" [ref=e880] [cursor=pointer]
              - button "Hủy" [ref=e881] [cursor=pointer]
        - row [ref=e882]:
          - cell "#3" [ref=e883]
          - cell "HW04 User" [ref=e884]
          - cell "60,000,000 ₫" [ref=e885]
          - cell "Chưa cập nhật" [ref=e886]
          - cell "Chờ xác nhận" [ref=e887]
          - cell [ref=e888]:
            - generic [ref=e889]:
              - button "Xác nhận" [ref=e890] [cursor=pointer]
              - button "Hủy" [ref=e891] [cursor=pointer]
        - row [ref=e892]:
          - cell "#2" [ref=e893]
          - cell "HW04 User" [ref=e894]
          - cell "58,000,000 ₫" [ref=e895]
          - cell "Chưa cập nhật" [ref=e896]
          - cell "Chờ xác nhận" [ref=e897]
          - cell [ref=e898]:
            - generic [ref=e899]:
              - button "Xác nhận" [ref=e900] [cursor=pointer]
              - button "Hủy" [ref=e901] [cursor=pointer]
        - row [ref=e902]:
          - cell "#1" [ref=e903]
          - cell "HW04 User" [ref=e904]
          - cell "30,000,000 ₫" [ref=e905]
          - cell "Chưa cập nhật" [ref=e906]
          - cell "Chờ xác nhận" [ref=e907]
          - cell [ref=e908]:
            - generic [ref=e909]:
              - button "Xác nhận" [ref=e910] [cursor=pointer]
              - button "Hủy" [ref=e911] [cursor=pointer]
```

# Test source

```ts
  90  |   await expect
  91  |     .poll(async () => (await readKpi(orderCountTile(page))) - base, {
  92  |       message: `Dashboard total orders must change by ${delta} (SRS FR-13)`,
  93  |     })
  94  |     .toBe(delta);
  95  | }
  96  | 
  97  | test.beforeAll(async ({ request }) => {
  98  |   await ensureAtLeastOneOrder(request);
  99  | });
  100 | 
  101 | test.describe('FR-13 Dashboard figures', () => {
  102 |   for (const sc of scenarios) {
  103 |     test(`${sc.id} - ${sc.title}`, async ({ page, request }) => {
  104 |       const adminToken = await loginApi(request, 'admin');
  105 |       const userToken = await loginApi(request, 'user');
  106 |       const before = await listOrders(request, adminToken);
  107 | 
  108 |       // ---------------------------------------------------------------- absolute value
  109 |       if (sc.mode === 'absolute') {
  110 |         await openAdmin(page, { token: adminToken });
  111 |         await waitDashboardLoaded(page);
  112 |         await expect
  113 |           .poll(() => readKpi(revenueTile(page)), {
  114 |             message: 'Dashboard revenue must equal the sum of total_amount of ALL delivered orders (SRS FR-13)',
  115 |           })
  116 |           .toBe(revenueOf(before));
  117 |         await expect
  118 |           .poll(() => readKpi(orderCountTile(page)), {
  119 |             message: 'Dashboard total orders must equal the number of orders in the system (SRS FR-13)',
  120 |           })
  121 |           .toBe(before.length);
  122 |         return;
  123 |       }
  124 | 
  125 |       // ---------------------------------------------------------------- orders are arranged through the API
  126 |       if (sc.mode === 'api-seed') {
  127 |         await openAdmin(page, { token: adminToken });
  128 |         await waitDashboardLoaded(page);
  129 |         const revenue0 = await readKpi(revenueTile(page));
  130 |         const count0 = await readKpi(orderCountTile(page));
  131 | 
  132 |         for (const o of sc.orders) {
  133 |           const id = await createOrder(request, userToken, o.amount);
  134 |           await moveOrderTo(request, adminToken, id, o.finalStatus);
  135 |         }
  136 | 
  137 |         // The data row must agree with the SRS rule, otherwise the data file (not the SUT) is wrong.
  138 |         const after = await listOrders(request, adminToken);
  139 |         expect(revenueOf(after) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  140 |         expect(after.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  141 | 
  142 |         await page.reload();
  143 |         await waitDashboardLoaded(page);
  144 |         await expectRevenueDelta(page, revenue0, sc.expect.revenueDelta as number);
  145 |         await expectCountDelta(page, count0, sc.expect.countDelta as number, sc.countVerdict);
  146 |         return;
  147 |       }
  148 | 
  149 |       // ---------------------------------------------------------------- the status is changed with the admin UI buttons
  150 |       if (sc.mode === 'ui-walk') {
  151 |         const amount = sc.orders[0].amount;
  152 |         const id = await createOrder(request, userToken, amount); // stays 'pending'
  153 | 
  154 |         await openAdmin(page, { token: adminToken });
  155 |         await waitDashboardLoaded(page);
  156 |         const revenue0 = await readKpi(revenueTile(page));
  157 |         const count0 = await readKpi(orderCountTile(page)); // already includes the new pending order
  158 | 
  159 |         await goToTab(page, 'Đơn hàng');
  160 |         const row = orderRow(page, id);
  161 |         await expect(row.locator('span').filter({ hasText: STATUS_LABEL.pending })).toBeVisible();
  162 | 
  163 |         for (const next of sc.walk ?? []) {
  164 |           await row.getByRole('button', { name: ACTION_BUTTON[next], exact: true }).click();
  165 |           await expect(row.locator('span').filter({ hasText: STATUS_LABEL[next] })).toBeVisible();
  166 | 
  167 |           // After every click the dashboard must follow the SRS rule: revenue moves only when 'delivered' is reached.
  168 |           await goToTab(page, 'Dashboard');
  169 |           await expectRevenueDelta(page, revenue0, next === 'delivered' ? amount : 0);
  170 |           await expectCountDelta(page, count0, 0, sc.countVerdict);
  171 |           await goToTab(page, 'Đơn hàng');
  172 |         }
  173 | 
  174 |         const finalList = await listOrders(request, adminToken);
  175 |         expect(revenueOf(finalList) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  176 |         expect(finalList.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  177 |         return;
  178 |       }
  179 | 
  180 |       // ---------------------------------------------------------------- final states offer no action (FR-10)
  181 |       const finalStatus = sc.orders[0].finalStatus;
  182 |       const id = await createOrder(request, userToken, sc.orders[0].amount);
  183 |       await moveOrderTo(request, adminToken, id, finalStatus);
  184 | 
  185 |       await openAdmin(page, { token: adminToken });
  186 |       await goToTab(page, 'Đơn hàng');
  187 |       const row = orderRow(page, id);
  188 |       await expect(row.locator('span').filter({ hasText: STATUS_LABEL[finalStatus] })).toBeVisible();
  189 |       // SRS FR-10: delivered / canceled are final states, no transition may be offered.
> 190 |       await expect(row.getByRole('button'), 'a final-state order must offer no action button').toHaveCount(0);
      |                                                                                                ^ Error: a final-state order must offer no action button
  191 |     });
  192 |   }
  193 | });
  194 | 
  195 | test.describe('FR-13 / FR-12 Admin access', () => {
  196 |   const expectLoginForm = async (page: Page) => {
  197 |     await expect(loginHeading(page), 'the login form must be shown').toBeVisible();
  198 |     await expect(dashboardHeading(page), 'the dashboard must not be shown').toBeHidden();
  199 |   };
  200 | 
  201 |   for (const ac of accessCases) {
  202 |     test(`${ac.id} - ${ac.title}`, async ({ page, request }) => {
  203 |       const dialogs = captureDialogs(page);
  204 | 
  205 |       if (ac.kind === 'no-token') {
  206 |         await openAdmin(page);
  207 |         await expectLoginForm(page);
  208 |       }
  209 | 
  210 |       if (ac.kind === 'inject-token') {
  211 |         const token = ac.token === 'user' ? await loginApi(request, 'user') : (ac.tokenValue as string);
  212 |         await openAdmin(page, { token, waitForOrders: false });
  213 |         await expectLoginForm(page);
  214 |       }
  215 | 
  216 |       if (ac.kind === 'ui-login') {
  217 |         const creds =
  218 |           ac.account === 'throwaway-wrong-password'
  219 |             ? { email: (await registerThrowawayUser(request)).email, password: 'WrongPass1!' }
  220 |             : ACCOUNTS[ac.account as 'admin' | 'user'];
  221 | 
  222 |         await openAdmin(page);
  223 |         await uiLogin(page, creds.email, creds.password);
  224 | 
  225 |         if (ac.expect === 'dashboard') {
  226 |           await expect(dashboardHeading(page)).toBeVisible();
  227 |           await expect(revenueTile(page)).toBeVisible();
  228 |           await expect(orderCountTile(page)).toBeVisible();
  229 |           expect(await page.evaluate(() => window.localStorage.getItem('adminToken'))).toBeTruthy();
  230 |         } else {
  231 |           await expectLoginForm(page);
  232 |           expect(await page.evaluate(() => window.localStorage.getItem('adminToken'))).toBeNull();
  233 |           // The SRS does not define the message text, so it is recorded, not asserted.
  234 |           test.info().annotations.push({
  235 |             type: 'CLARIFY',
  236 |             description: `Message shown to the user: ${dialogs.join(' | ') || '(none)'}`,
  237 |           });
  238 |         }
  239 |       }
  240 |     });
  241 |   }
  242 | });
  243 | 
```