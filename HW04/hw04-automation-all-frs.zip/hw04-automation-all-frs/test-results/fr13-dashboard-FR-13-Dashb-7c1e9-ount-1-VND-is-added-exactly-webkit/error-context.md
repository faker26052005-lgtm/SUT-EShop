# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr13-dashboard.spec.ts >> FR-13 Dashboard figures >> S06 - Boundary: smallest delivered amount (1 VND) is added exactly
- Location: tests\fr13-dashboard.spec.ts:103:5

# Error details

```
Error: Dashboard revenue must change by 1 (SRS FR-13: only delivered orders are summed)

Dashboard revenue must change by 1 (SRS FR-13: only delivered orders are summed)

expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 2

Call Log:
- Timeout 7000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - generic [ref=f1e4]:
    - heading "EShop Admin" [level=1] [ref=f1e5]
    - list [ref=f1e6]:
      - listitem [ref=f1e7] [cursor=pointer]: Dashboard
      - listitem [ref=f1e8] [cursor=pointer]: Danh mục
      - listitem [ref=f1e9] [cursor=pointer]: Sản phẩm
      - listitem [ref=f1e10] [cursor=pointer]: Mã Giảm Giá
      - listitem [ref=f1e11] [cursor=pointer]: Đơn hàng
      - listitem [ref=f1e12] [cursor=pointer]: Người dùng
      - listitem [ref=f1e13] [cursor=pointer]: Đăng xuất
  - generic [ref=f1e15]:
    - heading "Dashboard" [level=2] [ref=f1e16]
    - generic [ref=f1e17]:
      - generic [ref=f1e18]:
        - heading "Tổng doanh thu (Delivered)" [level=3] [ref=f1e19]
        - paragraph [ref=f1e20]: 8,594,534,594 ₫
      - generic [ref=f1e21]:
        - heading "Tổng số đơn hàng" [level=3] [ref=f1e22]
        - paragraph [ref=f1e23]: "88"
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import type { Page } from '@playwright/test';
  3   | import { loadData } from './helpers/data';
  4   | import { ACCOUNTS } from './helpers/env';
  5   | import {
  6   |   createOrder,
  7   |   ensureAtLeastOneOrder,
  8   |   listOrders,
  9   |   loginApi,
  10  |   moveOrderTo,
  11  |   registerThrowawayUser,
  12  |   revenueOf,
  13  | } from './helpers/api';
  14  | import type { Status } from './helpers/api';
  15  | import {
  16  |   ACTION_BUTTON,
  17  |   STATUS_LABEL,
  18  |   captureDialogs,
  19  |   dashboardHeading,
  20  |   goToTab,
  21  |   loginHeading,
  22  |   openAdmin,
  23  |   orderCountTile,
  24  |   orderRow,
  25  |   readKpi,
  26  |   revenueTile,
  27  |   uiLogin,
  28  |   waitDashboardLoaded,
  29  | } from './helpers/admin';
  30  | 
  31  | /**
  32  |  * FR-13 Dashboard (admin web, http://localhost:5174)
  33  |  * SRS: revenue = sum of total_amount of orders with status 'delivered'; also show the total number of orders.
  34  |  * Related: FR-12 access control, FR-10 order state machine (the dashboard depends on order status).
  35  |  *
  36  |  * Oracle = the SRS, applied to the order list returned by GET /api/admin/orders (verified in HW02).
  37  |  * Test data = data/fr13-dashboard.json and data/fr13-access.json.
  38  |  *
  39  |  * Why most scenarios check a CHANGE (delta) of the tiles: the database already holds old orders, so the absolute
  40  |  * numbers are arbitrary. A delta isolates the rule under test ("a pending order adds nothing"), and one dedicated
  41  |  * scenario (S13) anchors the absolute value.
  42  |  */
  43  | 
  44  | type Scenario = {
  45  |   id: string;
  46  |   title: string;
  47  |   mode: 'api-seed' | 'ui-walk' | 'final-state' | 'absolute';
  48  |   orders: { amount: number; finalStatus: Status }[];
  49  |   walk?: Status[];
  50  |   expect: { revenueDelta?: number; countDelta?: number; noActionButtons?: boolean };
  51  |   countVerdict?: 'firm' | 'clarify';
  52  |   source?: string;
  53  | };
  54  | 
  55  | type AccessCase = {
  56  |   id: string;
  57  |   title: string;
  58  |   kind: 'ui-login' | 'no-token' | 'inject-token';
  59  |   account?: 'admin' | 'user' | 'throwaway-wrong-password';
  60  |   token?: 'user' | 'literal';
  61  |   tokenValue?: string;
  62  |   expect: 'reject' | 'dashboard' | 'login-form';
  63  |   source?: string;
  64  | };
  65  | 
  66  | const scenarios = loadData<Scenario[]>('fr13-dashboard.json');
  67  | const accessCases = loadData<AccessCase[]>('fr13-access.json');
  68  | 
  69  | const CLARIFY_COUNT =
  70  |   'SRS does not say whether canceled orders are part of "total number of orders"; the value shown is recorded, not judged.';
  71  | 
  72  | /** Revenue tile must have moved by `delta` since `base` (assertion pattern: polling numeric equality). */
  73  | async function expectRevenueDelta(page: Page, base: number, delta: number) {
  74  |   await expect
  75  |     .poll(async () => (await readKpi(revenueTile(page))) - base, {
  76  |       message: `Dashboard revenue must change by ${delta} (SRS FR-13: only delivered orders are summed)`,
  77  |     })
> 78  |     .toBe(delta);
      |      ^ Error: Dashboard revenue must change by 1 (SRS FR-13: only delivered orders are summed)
  79  | }
  80  | 
  81  | async function expectCountDelta(page: Page, base: number, delta: number, verdict: 'firm' | 'clarify' = 'firm') {
  82  |   if (verdict === 'clarify') {
  83  |     const shown = await readKpi(orderCountTile(page));
  84  |     test.info().annotations.push({
  85  |       type: 'CLARIFY',
  86  |       description: `${CLARIFY_COUNT} Order tile moved from ${base} to ${shown} (expected change if all orders count: ${delta}).`,
  87  |     });
  88  |     return;
  89  |   }
  90  |   await expect
  91  |     .poll(async () => (await readKpi(orderCountTile(page))) - base, {
  92  |       message: `Dashboard total orders must change by ${delta} (SRS FR-13)`,
  93  |     })
  94  |     .toBe(delta);
  95  | }
  96  | 
  97  | test.beforeAll(async ({ request }) => {
  98  |   await ensureAtLeastOneOrder(request);
  99  | });
  100 | 
  101 | test.describe('FR-13 Dashboard figures', () => {
  102 |   for (const sc of scenarios) {
  103 |     test(`${sc.id} - ${sc.title}`, async ({ page, request }) => {
  104 |       const adminToken = await loginApi(request, 'admin');
  105 |       const userToken = await loginApi(request, 'user');
  106 |       const before = await listOrders(request, adminToken);
  107 | 
  108 |       // ---------------------------------------------------------------- absolute value
  109 |       if (sc.mode === 'absolute') {
  110 |         await openAdmin(page, { token: adminToken });
  111 |         await waitDashboardLoaded(page);
  112 |         await expect
  113 |           .poll(() => readKpi(revenueTile(page)), {
  114 |             message: 'Dashboard revenue must equal the sum of total_amount of ALL delivered orders (SRS FR-13)',
  115 |           })
  116 |           .toBe(revenueOf(before));
  117 |         await expect
  118 |           .poll(() => readKpi(orderCountTile(page)), {
  119 |             message: 'Dashboard total orders must equal the number of orders in the system (SRS FR-13)',
  120 |           })
  121 |           .toBe(before.length);
  122 |         return;
  123 |       }
  124 | 
  125 |       // ---------------------------------------------------------------- orders are arranged through the API
  126 |       if (sc.mode === 'api-seed') {
  127 |         await openAdmin(page, { token: adminToken });
  128 |         await waitDashboardLoaded(page);
  129 |         const revenue0 = await readKpi(revenueTile(page));
  130 |         const count0 = await readKpi(orderCountTile(page));
  131 | 
  132 |         for (const o of sc.orders) {
  133 |           const id = await createOrder(request, userToken, o.amount);
  134 |           await moveOrderTo(request, adminToken, id, o.finalStatus);
  135 |         }
  136 | 
  137 |         // The data row must agree with the SRS rule, otherwise the data file (not the SUT) is wrong.
  138 |         const after = await listOrders(request, adminToken);
  139 |         expect(revenueOf(after) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  140 |         expect(after.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  141 | 
  142 |         await page.reload();
  143 |         await waitDashboardLoaded(page);
  144 |         await expectRevenueDelta(page, revenue0, sc.expect.revenueDelta as number);
  145 |         await expectCountDelta(page, count0, sc.expect.countDelta as number, sc.countVerdict);
  146 |         return;
  147 |       }
  148 | 
  149 |       // ---------------------------------------------------------------- the status is changed with the admin UI buttons
  150 |       if (sc.mode === 'ui-walk') {
  151 |         const amount = sc.orders[0].amount;
  152 |         const id = await createOrder(request, userToken, amount); // stays 'pending'
  153 | 
  154 |         await openAdmin(page, { token: adminToken });
  155 |         await waitDashboardLoaded(page);
  156 |         const revenue0 = await readKpi(revenueTile(page));
  157 |         const count0 = await readKpi(orderCountTile(page)); // already includes the new pending order
  158 | 
  159 |         await goToTab(page, 'Đơn hàng');
  160 |         const row = orderRow(page, id);
  161 |         await expect(row.locator('span').filter({ hasText: STATUS_LABEL.pending })).toBeVisible();
  162 | 
  163 |         for (const next of sc.walk ?? []) {
  164 |           await row.getByRole('button', { name: ACTION_BUTTON[next], exact: true }).click();
  165 |           await expect(row.locator('span').filter({ hasText: STATUS_LABEL[next] })).toBeVisible();
  166 | 
  167 |           // After every click the dashboard must follow the SRS rule: revenue moves only when 'delivered' is reached.
  168 |           await goToTab(page, 'Dashboard');
  169 |           await expectRevenueDelta(page, revenue0, next === 'delivered' ? amount : 0);
  170 |           await expectCountDelta(page, count0, 0, sc.countVerdict);
  171 |           await goToTab(page, 'Đơn hàng');
  172 |         }
  173 | 
  174 |         const finalList = await listOrders(request, adminToken);
  175 |         expect(revenueOf(finalList) - revenueOf(before), 'data-file revenueDelta').toBe(sc.expect.revenueDelta);
  176 |         expect(finalList.length - before.length, 'data-file countDelta').toBe(sc.expect.countDelta);
  177 |         return;
  178 |       }
```